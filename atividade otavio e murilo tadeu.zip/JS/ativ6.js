 // Função para aumentar o número quando o botão for clicado
 function aumentarNumero() {
    var numeroElement = document.getElementById("numero");
    var numeroAtual = parseInt(numeroElement.textContent);
    numeroElement.textContent = numeroAtual + 1;

  
  }

