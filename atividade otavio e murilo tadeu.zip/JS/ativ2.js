var nota="MIN DE NOTA";

function bt(){
 window.alert(nota);
}