function alta() {

    //2° referncia da localização da teg
    
    

    
    let frase = document.getElementById("a").value;
    let result = frase.toUpperCase();
    document.getElementById("demo").innerHTML = result;
}
