var nota="MIN DE NOTA";

window.alert(nota);